<template>
  <div>
    <!-- set progressbar -->
    <vue-progress-bar></vue-progress-bar>
    <router-view></router-view>
  </div>
</template>

<style>
[v-cloak] {
  display: none;
}
</style>
