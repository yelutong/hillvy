export default {
  /**
   * @desc 右侧菜单数据
   */
  state: {
    userName: '京州市委书记李达康',
    menus: [{
      text: '巨头'
    }, {
      text: '人物'
    }, {
      text: '电商'
    }, {
      text: '创投'
    }, {
      text: '智能硬件'
    }, {
      text: '互联网+'
    }, {
      text: 'P2P'
    }, {
      text: '前沿技术'
    }, {
      text: '游戏'
    }]
  }
}
