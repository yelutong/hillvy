<template>
	<div class="search">
		你好  search
	</div>
</template>

<script>
	export default {

	}
</script>

<style lang="stylus" rel="stylesheet/stylus">
	.search
		font-size:12px
</style>
